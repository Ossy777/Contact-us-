document.getElementById('main-form').addEventListener('submit', function(event) {
  event.preventDefault();

  let name = document.getElementById('name').value;
  let email = document.getElementById('email').value;
  let password = document.getElementById('password').value;
  let message = document.getElementById('message').value;

  if (name === '' || email === '' || password === '' || message === '') {
    alert('Please fill out all fields.');
  } else {
    alert('Form submitted successfully!');
    document.getElementById('main-form').submit();
  }
});
document.getElementById('name').addEventListener('input', function() {
  if (this.value !== '') {
    this.style.borderColor = 'green';
  } else {
    this.style.borderColor = '#ccc';
  }
});